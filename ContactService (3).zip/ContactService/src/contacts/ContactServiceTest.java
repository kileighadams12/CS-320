package contacts;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setup() {
        service = new ContactService();
    }

    @Test
    void add_usesUniqueId_andStoresContact() {
        Contact a = new Contact("1", "A", "B", "0123456789", "addr");
        Contact dup = new Contact("1", "X", "Y", "1112223333", "addr2");

        assertTrue(service.add(a));
        assertFalse(service.add(dup));            
        assertEquals("A", service.get("1").getFirstName());
    }

    @Test
    void update_replacesFieldsForExistingId() {
        service.add(new Contact("1", "A", "B", "0123456789", "addr"));

        Contact updated = new Contact("1", "NewFirst", "NewLast", "1112223333", "New Address");
        assertTrue(service.update(updated));

        Contact c = service.get("1");
        assertEquals("NewFirst", c.getFirstName());
        assertEquals("NewLast",  c.getLastName());
        assertEquals("1112223333", c.getPhone());
        assertEquals("New Address", c.getAddress());
    }

    @Test
    void update_returnsFalseIfIdMissing() {
        Contact ghost = new Contact("missing", "A", "B", "0123456789", "addr");
        assertFalse(service.update(ghost));
    }

    @Test
    void remove_deletesByContactObject() {
        Contact a = new Contact("1", "A", "B", "0123456789", "addr");
        service.add(a);
        assertTrue(service.remove(a));
        assertNull(service.get("1"));
        assertFalse(service.remove(a)); 
    }

    @Test
    void idHelpersStillWork_perRubric() {
        service.add(new Contact("1", "A", "B", "0123456789", "addr"));
        assertTrue(service.updateFirstName("1", "Zoe"));
        assertTrue(service.updateAddress("1", "Somewhere"));

        assertEquals("Zoe", service.get("1").getFirstName());
        assertTrue(service.deleteById("1"));
        assertNull(service.get("1"));
    }
}



