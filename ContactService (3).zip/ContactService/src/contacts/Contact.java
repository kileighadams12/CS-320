package contacts;

import java.util.Objects;

public class Contact {
	private final String contactId;   
	private String firstName;         
    private String lastName;        
    private String phone;            
    private String address;          

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
    	this.contactId = validateId(contactId);
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }
 

    // --- validators ---
    private static String validateId(String id) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("contactId is required and must be at most 10 characters");
        }
        return id;
    }

    private static String validateName(String value, String field) {
        if (value == null || value.length() > 10) {
            throw new IllegalArgumentException(field + " is required and must be at most 10 characters");
        }
        return value;
    }

    private static String validatePhone(String phone) {
        if (phone == null || phone.length() != 10 || !phone.chars().allMatch(Character::isDigit)) {
            throw new IllegalArgumentException("phone is required and must be exactly 10 digits");
        }
        return phone;
    }

    private static String validateAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("address is required and must be at most 30 characters");
        }
        return address;
    }

    // --- getters ---
    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName;  }
    public String getPhone()     { return phone;     }
    public String getAddress()   { return address;   }

    // --- updatable fields ---
    public void setFirstName(String firstName) { this.firstName = validateName(firstName, "firstName"); }
    public void setLastName(String lastName)   { this.lastName  = validateName(lastName, "lastName");  }
    public void setPhone(String phone)         { this.phone     = validatePhone(phone);                }
    public void setAddress(String address)     { this.address   = validateAddress(address);            }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;
        Contact c = (Contact) o;
        return contactId.equals(c.contactId);
    }

    @Override
    public int hashCode() { return Objects.hash(contactId); }
}

        