package contacts;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void createsValidContact() {
        Contact c = new Contact("12345", "Alice", "Smith", "1234567890", "10 Main St");
        assertEquals("12345", c.getContactId());
        assertEquals("Alice", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("10 Main St", c.getAddress());
    }

    @Test
    void rejectsNullOrTooLongId() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, "A", "B", "0123456789", "addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("toolong-id-11", "A", "B", "0123456789", "addr"));
    }

    @Test
    void firstNameMustBePresentAndMax10() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", null, "B", "0123456789", "addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "abcdefghijkl", "B", "0123456789", "addr"));
    }

    @Test
    void lastNameMustBePresentAndMax10() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", null, "0123456789", "addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", "abcdefghijkl", "0123456789", "addr"));
    }

    @Test
    void phoneMustBeExactly10Digits() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", "B", null, "addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", "B", "12345", "addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", "B", "12345678901", "addr"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", "B", "12345abcde", "addr"));
    }

    @Test
    void addressMustBePresentAndMax30() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", "B", "0123456789", null));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "A", "B", "0123456789",
                        "this address string is longer than thirty chars"));
    }

    @Test
    void settersUpdateAllowedFieldsOnly() {
        Contact c = new Contact("1", "A", "B", "0123456789", "addr");
        c.setFirstName("NewFirst");
        c.setLastName("NewLast");
        c.setPhone("1112223333");
        c.setAddress("New Address");
        assertEquals("1", c.getContactId());
        assertEquals("NewFirst", c.getFirstName());
        assertEquals("NewLast", c.getLastName());
        assertEquals("1112223333", c.getPhone());
        assertEquals("New Address", c.getAddress());
    }
}
